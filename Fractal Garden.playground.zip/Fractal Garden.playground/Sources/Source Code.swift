// Code inside modules can be shared between pages and other source files.
import UIKit
public struct Game {
    public enum GameTheme: String {
        case natural = "Natural"
        case autumn = "Autumn"
        case fantasy = "Fantasy"
    }
    public static var maxIterations = 10
    public static var theme: GameTheme = .natural
    public static let animationDuration = 1.0
    static var branches: [Branch] = []
    public static func findBranches(in tree: Branch) {
        branches = tree.allSubBranches
    }
    public static var lookForCuts = true
    public static func cutBranch(_ point: CGPoint, tree: Branch, view: UIView) {
        if branches.isEmpty { findBranches(in: tree)}
        for i in 0 ..< branches.count {
            let branch = branches[i]
            if !branch.alive { continue }
            if let reg = branch.region {
                if reg.check(point: point) {
                    branch.destroy()
                    return
                }
            }
            
        }
        
    }
}
public class BranchLayer: CAShapeLayer {
    weak var branch: Branch?
}
class BranchRegion {
    var startPos: CGPoint
    var endPos: CGPoint
    var x1: CGFloat
    var x2: CGFloat
    var y1: CGFloat
    var y2: CGFloat
    let K: CGFloat = 2
    lazy var m = (y2 - y1) / (x2 - x1)
    init(startPos: CGPoint, endPos: CGPoint) {
        // Make sure the points are left to right first
        if startPos.x <= endPos.x {
            self.startPos = startPos
            self.endPos = endPos
        } else {
            self.startPos = endPos
            self.endPos = startPos
        }
        
        x1 = self.startPos.x
        x2 = self.endPos.x
        y1 = self.startPos.y
        y2 = self.endPos.y
    }
    func maxAllowedY(for x: CGFloat) -> CGFloat {
        (m * (x - x1) + y1 + K)
    }
    func minAllowedY(for x: CGFloat) -> CGFloat {
        (m * (x - x1) + y1 - K)
    }
    func check(point: CGPoint) -> Bool {
        let (a, b) = (point.x, point.y)
        let inXRegion = a > x1 - K && a < x2 + K
        if x1 == x2 {
            return inXRegion && b > min(y1, y2) && b < max(y1, y2)
        }
        if inXRegion {
            if b <= maxAllowedY(for: a) && b >= minAllowedY(for: a) {
                return true
            }
        }
        return false
    }
}
public class Branch {
    public var view: UIView
    public var length: CGFloat = 50
    public var angle: CGFloat = 0
    public var position: CGPoint
    var endPosition: CGPoint = .zero
    var iterationNumber = 0
    var region: BranchRegion?
    public init(view: UIView, length: CGFloat, angle: CGFloat, position: CGPoint) {
        self.view = view
        self.length = length
        self.angle = angle
        self.position = position
    }
    weak var line: BranchLayer?
    weak var parentBranch: Branch?
    var subBranches: [Branch] = []
    var allSubBranches: [Branch] {
        subBranches + subBranches.lazy.flatMap({ $0.allSubBranches })
    }
    func generateRandomColor() -> UIColor {
        let redValue = CGFloat.random(in: 0...1)
        let greenValue = CGFloat.random(in: 0...1)
        let blueValue = CGFloat.random(in: 0...1)
            
        let randomColor = UIColor(red: redValue, green: greenValue, blue: blueValue, alpha: 1.0)
            
        return randomColor
        }
    func color() -> UIColor {
        if Game.theme == .fantasy {
            return generateRandomColor()
        }
        
        
        if iterationNumber < 4 {
            return .brown
        }
        if Game.theme == .autumn {
            return UIColor(hue: .random(in: 0 ... 1 / 9), saturation: .random(in: 0.8 ... 1), brightness: .random(in: 0.4 ... 1), alpha: 1)
        } else {
            var flowerThresh = Game.maxIterations
            if flowerThresh > 10 {
                flowerThresh = flowerThresh * 9 / 10
            }
            if iterationNumber < flowerThresh {
                return UIColor(hue: 1 / 3, saturation: .random(in: 0.7 ... 0.8), brightness: .random(in: 0.4 ... 0.8), alpha: 1)
            }
        }
        return generateRandomColor()
    }

    public func create() {
        if iterationNumber > Game.maxIterations { Game.lookForCuts = true; return }
        //design the path
        let path = UIBezierPath()
        path.move(to: position)
        let endPosition = CGPoint(x: position.x + length * sin(angle), y: position.y - length * cos(angle))
        path.addLine(to: endPosition)
        self.endPosition = endPosition
        
        self.region = BranchRegion(startPos: position, endPos: endPosition)
        
        
        //design path in layer
        let shapeLayer = BranchLayer()
        shapeLayer.branch = self
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = color().cgColor
        shapeLayer.lineWidth = 2
        
        shapeLayer.strokeEnd = 0
        view.layer.addSublayer(shapeLayer)
        
        
        // Animate path
        let pathAnimation: CABasicAnimation = CABasicAnimation(keyPath: "strokeEnd")
        pathAnimation.duration = Game.animationDuration
        pathAnimation.fromValue = 0
        pathAnimation.toValue = 1
        let delay = Game.animationDuration
        shapeLayer.add(pathAnimation, forKey: "grow")
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        //            print(iterationNumber, Game.animationDuration * Double(iterationNumber))
        shapeLayer.strokeEnd = 1
        CATransaction.commit()
        Time.delay(delay) { [self] in
            if !self.alive || !(self.parentBranch?.alive ?? true) {
                self.destroy()
                return
            }

            //        shapeLayer.name = "Branch \(iterationNumber)"
            self.line = shapeLayer
            
            var nextBranch = Branch(view: view, length: length * 0.8, angle: angle + .pi / 8, position: endPosition)
            nextBranch.iterationNumber = iterationNumber + 1
            subBranches.append(nextBranch)
            nextBranch.parentBranch = self
            nextBranch.create()
            
            nextBranch = Branch(view: view, length: length * 0.8, angle: angle - .pi / 8, position: endPosition)
            subBranches.append(nextBranch)
            nextBranch.iterationNumber = iterationNumber + 1
            nextBranch.parentBranch = self

            nextBranch.create()
        }
    }
    var alive = true
    public func destroy() {
        // Animate path
        let pathAnimation: CABasicAnimation = CABasicAnimation(keyPath: "opacity")
        pathAnimation.duration = 0.1
        pathAnimation.fromValue = 1
        pathAnimation.toValue = 0
        
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        line?.opacity = 0
        CATransaction.commit()

        line?.add(pathAnimation, forKey: "shrink")
        alive = false
        Time.delay(0.1) {
            self.line?.removeFromSuperlayer()
            self.subBranches.forEach({ $0.destroy() })
            self.subBranches = []
        }
    }
    

}

public struct Time {
    @discardableResult public static func delayedItem(_ delay: Double, closure: @escaping () -> () ) -> DispatchWorkItem {
        let work = DispatchWorkItem(block: closure)
        let when = DispatchTime.now() + delay
        DispatchQueue.main.asyncAfter(deadline: when, execute: work)
        return work
    }
    static public func delay(_ delay: Double, closure: @escaping () -> () ) {
        let when = DispatchTime.now() + delay
        DispatchQueue.main.asyncAfter(deadline: when, execute: closure)
    }
    @discardableResult static public func repeating(_ interval: TimeInterval, closure: @escaping (_ timer: Timer) -> () ) -> Timer {
        Timer.scheduledTimer(withTimeInterval: interval, repeats: true) { (timer) in
            closure(timer)
        }
    }
}
public extension UIView {
    func constrain(to overrideView: UIView? = nil) {
        guard let sup = overrideView ?? superview else { return }
        translatesAutoresizingMaskIntoConstraints = false
        leadingAnchor.constraint(equalTo: sup.leadingAnchor).isActive = true
        trailingAnchor.constraint(equalTo: sup.trailingAnchor).isActive = true
        topAnchor.constraint(equalTo: sup.topAnchor).isActive = true
        bottomAnchor.constraint(equalTo: sup.bottomAnchor).isActive = true
    }
}

open class FractalViewController : UIViewController {
    public var tree: Branch?
    public var bgImage: UIImageView!
    public var iconImage: UIImageView!
    
    public func setupOpening(in view: UIView) {
        bgImage = UIImageView(image: #imageLiteral(resourceName: "Fractal BG.png"))
        bgImage.frame = view.bounds
        bgImage.contentMode = .scaleAspectFill
        view.addSubview(bgImage)
        bgImage.constrain()
        iconImage = UIImageView(image: #imageLiteral(resourceName: "Fractal Gardens Logo.png"))
//        iconImage.layer.name = "icon"
        iconImage.frame = CGRect(x: 0, y: 0, width: 300, height: 200)
        iconImage.contentMode = .scaleAspectFit
        iconImage.isHidden = true
        view.addSubview(iconImage)
        

    }

    public func popView(_ view: UIView, completion: ((Bool)->Void)? = nil) {
        popInView(view) { _ in
            self.popOutView(view, completion: completion)
        }

    }
    
    func popInView(_ view: UIView, completion: ((Bool)->Void)? = nil) {
        view.center = bgImage.center
        view.isHidden = false
        view.alpha = 0
        UIView.animate(withDuration: 2, delay: 1, animations: {
            view.alpha = 1
        }, completion: completion)
        
    }
    func popOutView(_ view: UIView, completion: ((Bool)->Void)? = nil) {
        UIView.animate(withDuration: 2, animations: {
            view.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            view.alpha = 0
        }, completion: completion)
    }
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        guard Game.lookForCuts, let tree = tree, let touchSpot = touches.first?.location(in: view) else { return }
//        print(touchSpot)
        if touchSpot.y > view.center.y { return }
        Game.cutBranch(touchSpot, tree: tree, view: view)
    }
    
}
