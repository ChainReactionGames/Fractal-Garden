import UIKit
import PlaygroundSupport

class GardenViewController: FractalViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        setupOpening(in: view)
        
        self.view = view
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.popView(iconImage) { _ in
            self.setupUI()
            self.createTree()
        }
        
    }
    
    var iterations = 10
    var theme = Game.GameTheme.natural
    
    @objc func createTree() {
        if !Game.lookForCuts { return }
        tree?.destroy()
        Game.maxIterations = iterations
        Game.theme = theme
        
        let branch = Branch(view: view, length: 50, angle: 0, position: view.center)
        branch.create()
        Game.findBranches(in: branch)
        self.tree = branch
        Game.lookForCuts = false
        
    }
    
    
    

    func setupUI() {
        var viewsToAnimate = [UIView]()
        
        let pot = UIImageView(image: UIImage(named: "pot")) //600x475
        pot.frame.size = CGSize(width: 150, height: 475 / 4)
        pot.center = view.center
        pot.center.y += 475 / 8
        pot.alpha = 0
        
        viewsToAnimate.append(pot)
        view.addSubview(pot)
        
        let iterationsControl = UISegmentedControl(frame: CGRect(x: 0, y: 475, width: 325, height: 30))
        for i in 0 ..< iterationsOptions.count {
            iterationsControl.insertSegment(withTitle: "\(iterationsOptions[i]) Loops", at: i, animated: false)
        }
        iterationsControl.selectedSegmentIndex = 2
        iterationsControl.addTarget(self, action: #selector(branchSegments(_:)), for: .valueChanged)
        viewsToAnimate.append(iterationsControl)
        view.addSubview(iterationsControl)
        iterationsControl.center.x = bgImage.center.x

        let themeControl = UISegmentedControl(frame: CGRect(x: 0, y: 525, width: 325, height: 30))
        for i in 0 ..< themeOptions.count {
            themeControl.insertSegment(withTitle: themeOptions[i].rawValue, at: i, animated: false)
        }
        themeControl.selectedSegmentIndex = 0
        themeControl.addTarget(self, action: #selector(themeSegments(_:)), for: .valueChanged)
        viewsToAnimate.append(themeControl)
        view.addSubview(themeControl)
        themeControl.center.x = bgImage.center.x
        
        let plantBtn = UIButton(frame: CGRect(x: 0, y: 590, width: 150, height: 215 / 4)) //600 x 215
        plantBtn.setImage(UIImage(named: "PlantBtn"), for: .normal)
        plantBtn.addTarget(self, action: #selector(createTree), for: .touchUpInside)
        viewsToAnimate.append(plantBtn)
        view.addSubview(plantBtn)
        plantBtn.center.x = view.center.x
        
        let instructions = UIImageView(image: UIImage(named: "Instructions"))
        instructions.frame = CGRect(x: 0, y: 20, width: 150, height: 83 / 4) // 600 x 83
        viewsToAnimate.append(instructions)
        view.addSubview(instructions)
        instructions.center.x = view.center.x
        
        viewsToAnimate.forEach({ $0.alpha = 0 })
        UIView.animate(withDuration: 2) {
            viewsToAnimate.forEach({ $0.alpha = 1 })
        }

    }
    let iterationsOptions = [5, 7, 10, 12, 14]
    let themeOptions = [Game.GameTheme.natural, .autumn, .fantasy]
    @objc func branchSegments(_ sender: UISegmentedControl) {
        let newIters = iterationsOptions[sender.selectedSegmentIndex]
        iterations = newIters
    }
    @objc func themeSegments(_ sender: UISegmentedControl) {
        theme = themeOptions[sender.selectedSegmentIndex]
    }

}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = GardenViewController()
